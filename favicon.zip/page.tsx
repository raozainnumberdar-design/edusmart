"use client";

import { useState, useEffect } from "react";

export default function Home() {
  const [active, setActive] = useState("Dashboard");
  const [studentName, setStudentName] = useState("Student");
  const [nameLoaded, setNameLoaded] = useState(false);

  // Name LocalStorage Fix
  useEffect(() => {
    const savedName = localStorage.getItem("edusmart-name");
    if (savedName) {
      setStudentName(savedName);
    }
    setNameLoaded(true);
  }, []);

  useEffect(() => {
    if (nameLoaded) {
      localStorage.setItem("edusmart-name", studentName);
    }
  }, [studentName, nameLoaded]);

  // Tasks State & LocalStorage
  const [newTask, setNewTask] = useState("");
  const [taskPriority, setTaskPriority] = useState("Medium");
  const [tasksLoaded, setTasksLoaded] = useState(false);
  const [tasks, setTasks] = useState([
    { title: "Complete Programming Assignment", done: false, priority: "High" },
    { title: "Revise Discrete Mathematics", done: false, priority: "Medium" },
    { title: "Prepare English Presentation", done: true, priority: "Low" },
  ]);

  useEffect(() => {
    const savedTasks = localStorage.getItem("edusmart-tasks");
    if (savedTasks) {
      try {
        setTasks(JSON.parse(savedTasks));
      } catch {
        console.log("Tasks load nahi huay");
      }
    }
    setTasksLoaded(true);
  }, []);

  useEffect(() => {
    if (tasksLoaded) {
      localStorage.setItem("edusmart-tasks", JSON.stringify(tasks));
    }
  }, [tasks, tasksLoaded]);

  const addTask = () => {
    if (!newTask.trim()) return;
    setTasks((old) => [
      ...old,
      { title: newTask.trim(), done: false, priority: taskPriority },
    ]);
    setNewTask("");
    setTaskPriority("Medium");
  };

  function deleteTask(index: number) {
    setTasks((old) => old.filter((_, i) => i !== index));
  }

  // Notes State & LocalStorage
  const [notesLoaded, setNotesLoaded] = useState(false);
  const [notes, setNotes] = useState({
    "Programming Fundamentals": "",
    "Discrete Mathematics": "",
    "Digital Logic Design": "",
  });

  useEffect(() => {
    const savedNotes = localStorage.getItem("edusmart-notes");
    if (savedNotes) {
      try {
        setNotes(JSON.parse(savedNotes));
      } catch {
        console.log("Could not load saved notes.");
      }
    }
    setNotesLoaded(true);
  }, []);

  useEffect(() => {
    if (notesLoaded) {
      localStorage.setItem("edusmart-notes", JSON.stringify(notes));
    }
  }, [notes, notesLoaded]);

  // Courses State & LocalStorage
  const [newCourseTitle, setNewCourseTitle] = useState("");
  const [coursesLoaded, setCoursesLoaded] = useState(false);
  const [courses, setCourses] = useState([
    { title: "Programming Fundamentals", percentage: 75, color: "#4f46e5" },
    { title: "Discrete Mathematics", percentage: 60, color: "#0891b2" },
    { title: "Functional English", percentage: 85, color: "#16a34a" },
    { title: "Digital Logic Design", percentage: 50, color: "#f59e0b" },
  ]);

  useEffect(() => {
    const savedCourses = localStorage.getItem("edusmart-courses");
    if (savedCourses) {
      try {
        setCourses(JSON.parse(savedCourses));
      } catch {
        console.log("Courses load nahi huay");
      }
    }
    setCoursesLoaded(true);
  }, []);

  useEffect(() => {
    if (coursesLoaded) {
      localStorage.setItem("edusmart-courses", JSON.stringify(courses));
    }
  }, [courses, coursesLoaded]);

  const addCourse = () => {
    if (!newCourseTitle.trim()) return;
    setCourses((old) => [
      ...old,
      { title: newCourseTitle.trim(), percentage: 0, color: "#4f46e5" },
    ]);
    setNewCourseTitle("");
  };

  function deleteCourse(index: number) {
    setCourses((old) => old.filter((_, i) => i !== index));
  }

  const menu = ["Dashboard", "My Courses", "My Tasks", "Study Notes"];

  const updateProgress = (index: number, newPercentage: number) => {
    setCourses((old) =>
      old.map((course, i) =>
        i === index ? { ...course, percentage: newPercentage } : course
      )
    );
  };

  return (
    <main
      style={{
        minHeight: "100vh",
        display: "flex",
        background: "#f5f7fb",
        color: "#172033",
        fontFamily: "Arial, sans-serif",
      }}
    >
      <aside
        style={{
          width: "225px",
          flexShrink: 0,
          background: "#172554",
          color: "white",
          padding: "28px 16px",
          boxSizing: "border-box",
        }}
      >
        <h2 style={{ color: "#a5b4fc", marginBottom: "38px" }}>EduSmart</h2>

        {menu.map((item) => (
          <button
            key={item}
            onClick={() => setActive(item)}
            style={{
              display: "block",
              width: "100%",
              textAlign: "left",
              padding: "14px",
              marginBottom: "8px",
              border: "none",
              borderRadius: "9px",
              background: active === item ? "#4f46e5" : "transparent",
              color: "white",
              fontSize: "15px",
              cursor: "pointer",
            }}
          >
            {item}
          </button>
        ))}

        <p
          style={{
            marginTop: "50px",
            fontSize: "12px",
            color: "#c7d2fe",
          }}
        >
          YOUR LEARNING JOURNEY
        </p>
      </aside>

      <section
        style={{
          flex: 1,
          minWidth: 0,
          padding: "30px",
        }}
      >
        <header
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            flexWrap: "wrap",
            gap: "12px",
            marginBottom: "30px",
          }}
        >
          <div>
            <h1 style={{ margin: 0, fontSize: "28px" }}>{active}</h1>
            <p
              style={{
                color: "#64748b",
                display: "flex",
                alignItems: "center",
                gap: "8px",
                flexWrap: "wrap",
              }}
            >
              Welcome back,
              <input
                value={studentName}
                onChange={(e) => setStudentName(e.target.value)}
                style={{
                  border: "none",
                  borderBottom: "2px solid #4f46e5",
                  background: "transparent",
                  fontWeight: "bold",
                  color: "#4f46e5",
                  fontSize: "16px",
                  outline: "none",
                  width: "120px",
                }}
              />
              ! Keep learning every day.
            </p>
          </div>
          <div
            style={{
              background: "white",
              padding: "12px 16px",
              borderRadius: "12px",
            }}
          >
            🎓 Student Dashboard
          </div>
        </header>

        {active === "Dashboard" && (
          <>
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))",
                gap: "18px",
                marginBottom: "28px",
              }}
            >
              {[
                ["📚", "Enrolled Courses", `${courses.length}`],
                ["✅", "Tasks Completed", `${tasks.filter((t) => t.done).length}`],
                ["⏰", "Study Hours", "12 hrs"],
              ].map(([icon, title, value]) => (
                <div
                  key={title}
                  style={{
                    background: "white",
                    padding: "23px",
                    borderRadius: "14px",
                    boxShadow: "0 4px 15px #17203308",
                  }}
                >
                  <div style={{ fontSize: "25px" }}>{icon}</div>
                  <p style={{ color: "#64748b", fontSize: "14px" }}>{title}</p>
                  <h2 style={{ margin: 0 }}>{value}</h2>
                </div>
              ))}
            </div>

            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))",
                gap: "22px",
              }}
            >
              <div
                style={{
                  background: "white",
                  padding: "24px",
                  borderRadius: "14px",
                }}
              >
                {courses.slice(0, 3).map((course) => (
                  <div key={course.title} style={{ marginBottom: "23px" }}>
                    <div
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        gap: "8px",
                        fontSize: "14px",
                      }}
                    >
                      <span>{course.title}</span>
                      <b>{course.percentage}%</b>
                    </div>
                    <div
                      style={{
                        height: "8px",
                        background: "#e2e8f0",
                        borderRadius: "10px",
                        marginTop: "10px",
                      }}
                    >
                      <div
                        style={{
                          width: `${course.percentage}%`,
                          height: "100%",
                          background: course.color,
                          borderRadius: "10px",
                        }}
                      />
                    </div>
                  </div>
                ))}
                <button
                  onClick={() => setActive("My Courses")}
                  style={{
                    background: "#eef2ff",
                    color: "#4338ca",
                    border: "none",
                    padding: "12px 16px",
                    borderRadius: "8px",
                    cursor: "pointer",
                  }}
                >
                  View All Courses
                </button>
              </div>

              <div
                style={{
                  background: "white",
                  padding: "24px",
                  borderRadius: "14px",
                }}
              >
                <h2>Today's Tasks</h2>
                {tasks.map((task, index) => (
                  <label
                    key={`${task.title}-${index}`}
                    style={{
                      display: "flex",
                      gap: "10px",
                      alignItems: "center",
                      justifyContent: "space-between",
                      padding: "13px 0",
                      borderBottom: "1px solid #f1f5f9",
                      cursor: "pointer",
                      color: task.done ? "#94a3b8" : "#334155",
                      textDecoration: task.done ? "line-through" : "none",
                    }}
                  >
                    <div style={{ display: "flex", gap: "10px", alignItems: "center" }}>
                      <input
                        type="checkbox"
                        checked={task.done}
                        onChange={() =>
                          setTasks((old) =>
                            old.map((t, i) =>
                              i === index ? { ...t, done: !t.done } : t
                            )
                          )
                        }
                      />
                      <span>{task.title}</span>
                    </div>

                    {/* DASHBOARD PRIORITY BADGE */}
                    <span
                      style={{
                        fontSize: "11px",
                        padding: "2px 8px",
                        borderRadius: "12px",
                        fontWeight: "bold",
                        backgroundColor:
                          task.priority === "High"
                            ? "#fee2e2"
                            : task.priority === "Low"
                            ? "#dcfce7"
                            : "#fef9c3",
                        color:
                          task.priority === "High"
                            ? "#ef4444"
                            : task.priority === "Low"
                            ? "#22c55e"
                            : "#ca8a04",
                      }}
                    >
                      {task.priority || "Medium"}
                    </span>
                  </label>
                ))}
                <p style={{ color: "#64748b", fontSize: "13px", marginTop: "15px" }}>
                  Tick a task when you finish it.
                </p>
              </div>
            </div>
          </>
        )}

        {active === "My Courses" && (
          <div
            style={{
              background: "white",
              padding: "25px",
              borderRadius: "14px",
            }}
          >
            <h2>Your Learning Courses</h2>

            <div
              style={{
                display: "flex",
                gap: "10px",
                marginBottom: "20px",
                marginTop: "15px",
              }}
            >
              <input
                value={newCourseTitle}
                onChange={(e) => setNewCourseTitle(e.target.value)}
                placeholder="Enter new course name"
                style={{
                  flex: 1,
                  minWidth: 0,
                  padding: "12px",
                  border: "1px solid #cbd5e1",
                  borderRadius: "8px",
                }}
              />
              <button
                onClick={addCourse}
                style={{
                  padding: "12px 18px",
                  background: "#4f46e5",
                  color: "white",
                  border: "none",
                  borderRadius: "8px",
                  cursor: "pointer",
                }}
              >
                Add Course
              </button>
            </div>

            {courses.map((course, index) => (
              <div
                key={`${course.title}-${index}`}
                style={{
                  padding: "16px",
                  background: "#f8fafc",
                  borderRadius: "8px",
                  marginBottom: "14px",
                }}
              >
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "10px" }}>
                  <span>{course.title}</span>
                  <div style={{ display: "flex", alignItems: "center", gap: "15px" }}>
                    <strong>{course.percentage}%</strong>
                    <button
                      onClick={() => deleteCourse(index)}
                      style={{
                        background: "#ef4444",
                        color: "white",
                        border: "none",
                        borderRadius: "6px",
                        padding: "6px 10px",
                        cursor: "pointer",
                        fontSize: "13px",
                      }}
                    >
                      Delete
                    </button>
                  </div>
                </div>

                <div
                  style={{
                    height: "8px",
                    background: "#e2e8f0",
                    borderRadius: "8px",
                    marginBottom: "10px",
                  }}
                >
                  <div
                    style={{
                      width: `${course.percentage}%`,
                      height: "8px",
                      background: course.color,
                      borderRadius: "8px",
                    }}
                  />
                </div>

                <input
                  type="range"
                  min="0"
                  max="100"
                  value={course.percentage}
                  onChange={(e) => updateProgress(index, Number(e.target.value))}
                  style={{ width: "100%", cursor: "pointer" }}
                />
              </div>
            ))}
          </div>
        )}

        {active === "My Tasks" && (
          <div
            style={{
              background: "white",
              padding: "25px",
              borderRadius: "14px",
            }}
          >
            <h2>Manage Your Tasks</h2>

            {/* INPUT + DROPDOWN + BUTTON */}
            <div style={{ display: "flex", gap: "10px", marginBottom: "20px" }}>
              <input
                value={newTask}
                onChange={(e) => setNewTask(e.target.value)}
                placeholder="Enter a new study task"
                style={{
                  flex: 1,
                  minWidth: 0,
                  padding: "12px",
                  border: "1px solid #cbd5e1",
                  borderRadius: "8px",
                }}
              />

              <select
                value={taskPriority}
                onChange={(e) => setTaskPriority(e.target.value)}
                style={{
                  padding: "12px",
                  borderRadius: "8px",
                  border: "1px solid #cbd5e1",
                  background: "white",
                  cursor: "pointer",
                  outline: "none",
                }}
              >
                <option value="High">🔴 High</option>
                <option value="Medium">🟡 Medium</option>
                <option value="Low">🟢 Low</option>
              </select>

              <button
                onClick={addTask}
                style={{
                  padding: "12px 18px",
                  background: "#4f46e5",
                  color: "white",
                  border: "none",
                  borderRadius: "8px",
                  cursor: "pointer",
                }}
              >
                Add Task
              </button>
            </div>

            {tasks.map((task, index) => (
              <div
                key={`${task.title}-${index}`}
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  gap: "12px",
                  padding: "16px 0",
                  borderBottom: "1px solid #e5e7eb",
                }}
              >
                <label
                  style={{ display: "flex", gap: "12px", alignItems: "center" }}
                >
                  <input
                    type="checkbox"
                    checked={task.done}
                    onChange={() =>
                      setTasks((old) =>
                        old.map((t, i) =>
                          i === index ? { ...t, done: !t.done } : t
                        )
                      )
                    }
                  />
                  <span
                    style={{
                      textDecoration: task.done ? "line-through" : "none",
                      color: task.done ? "#94a3b8" : "#334155",
                    }}
                  >
                    {task.title}
                  </span>

                  {/* MY TASKS TAB PRIORITY BADGE */}
                  <span
                    style={{
                      fontSize: "11px",
                      padding: "2px 8px",
                      borderRadius: "12px",
                      fontWeight: "bold",
                      backgroundColor:
                        task.priority === "High"
                          ? "#fee2e2"
                          : task.priority === "Low"
                          ? "#dcfce7"
                          : "#fef9c3",
                      color:
                        task.priority === "High"
                          ? "#ef4444"
                          : task.priority === "Low"
                          ? "#22c55e"
                          : "#ca8a04",
                    }}
                  >
                    {task.priority || "Medium"}
                  </span>
                </label>

                <button
                  onClick={() => deleteTask(index)}
                  style={{
                    background: "#ef4444",
                    color: "white",
                    border: "none",
                    borderRadius: "6px",
                    padding: "8px 12px",
                    cursor: "pointer",
                  }}
                >
                  Delete
                </button>
              </div>
            ))}
          </div>
        )}

        {active === "Study Notes" && (
          <div
            style={{
              background: "white",
              padding: "25px",
              borderRadius: "14px",
            }}
          >
            <h2>Study Notes</h2>

            {Object.keys(notes).map((subject) => (
              <div key={subject} style={{ marginBottom: "24px" }}>
                <h3>{subject}</h3>

                <textarea
                  value={notes[subject as keyof typeof notes]}
                  onChange={(e) =>
                    setNotes((old) => ({
                      ...old,
                      [subject]: e.target.value,
                    }))
                  }
                  placeholder={`Write your ${subject} notes here...`}
                  rows={4}
                  style={{
                    width: "100%",
                    padding: "12px",
                    border: "1px solid #cbd5e1",
                    borderRadius: "8px",
                    fontSize: "15px",
                    boxSizing: "border-box",
                  }}
                />
              </div>
            ))}

            <p style={{ color: "#64748b" }}>
              Your notes are saved automatically on this device.
            </p>
          </div>
        )}
      </section>
    </main>
  );
}